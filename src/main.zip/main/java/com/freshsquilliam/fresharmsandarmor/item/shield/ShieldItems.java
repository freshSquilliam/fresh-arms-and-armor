package com.freshsquilliam.fresharmsandarmor.item.shield;

import com.freshsquilliam.fresharmsandarmor.FreshArmsAndArmor;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ShieldItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, FreshArmsAndArmor.MODID);

    public static final RegistryObject<Item> WOODEN_SHIELD =
            ITEMS.register("wooden_shield",
                    () -> new Shields(
                            1, // +1 armor
                            new Item.Properties().durability(150)
                    ));

    public static final RegistryObject<Item> IRON_SHIELD =
            ITEMS.register("iron_shield",
                    () -> new Shields(
                            2, // +2 armor
                            new Item.Properties().durability(300)
                    ));

    public static final RegistryObject<Item> DIAMOND_SHIELD =
            ITEMS.register("diamond_shield",
                    () -> new Shields(
                            3, // +3 armor
                            new Item.Properties().durability(450)
                    ));

    public static final RegistryObject<Item> NETHERITE_SHIELD =
            ITEMS.register("netherite_shield",
                    () -> new Shields(
                            4, // +4 armor
                            new Item.Properties()
                                    .durability(600)
                                    .fireResistant()
                    ));
}
